package com.revature.project.banking.Dao;

import java.util.List;

import com.revature.project.banking.Model.Customer;
import com.revature.project.banking.Model.CustomerDeposit;
import com.revature.project.banking.Model.CustomerWithdraw;
import com.revature.project.banking.Model.Employee;
import com.revature.project.banking.Model.Feedback;
import com.revature.project.banking.Model.RequestTable;
import com.revature.project.banking.Model.TransferAmount;



public interface EmployeeDao {
	
	public boolean addEmployee(Employee employee);
	
	public List<Customer> getAllCustomer();
	 
	public Customer getCustomerById(int customerId);
	
	public boolean deleteAnCustomerById(int customerId); 
	
	public List<CustomerWithdraw> getAllWithdraws();
	
	public List<CustomerWithdraw> getWithdrawOfCustomerById(int customerId);
	
	public List<CustomerDeposit> getAllDeposits();
	
	public List<CustomerDeposit> getDepositOfCustomerById(int customerId);
	
	public List<TransferAmount> getCustomerTransferHistory();
	
	public List<Feedback> getCustomerFeedBack();
	
	public List<RequestTable> getAllRequests();
	
	public boolean approveCustomerRequest(int requestId);	
	
	public boolean rejectCustomerRequest(int customerId);
	
	public boolean employeeLogin(Employee employee);
	

}
