package com.revature.project.banking.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.revature.project.banking.Model.Customer;
import com.revature.project.banking.Model.CustomerDeposit;
import com.revature.project.banking.Model.CustomerWithdraw;
import com.revature.project.banking.Model.Feedback;
import com.revature.project.banking.Model.RequestTable;
import com.revature.project.banking.Model.TransferAmount;
import com.revature.project.banking.util.HibernateUtil;

public class CustomerDaoImpl implements CustomerDao {

	// Initializing Logger class for Banking.log file

	// CRUD Operations for Data Base

	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	Session session = sessionFactory.openSession();

	public boolean addCustomer(RequestTable requestTable) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();

		session.save(requestTable);
		transaction.commit();
		return true;
	}

	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		session.delete(customer);
		transaction.commit();
		return true;

	}

	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		session.update(customer);
		transaction.commit();
		return true;
	}

	public int getCustomerBalance(int customerId) {
		// TODO Auto-generated method stub
		Query query = session.createQuery(
				"select balance from com.revature.project.banking.Model.Customer where customerId = " + customerId);
		int balance = (Integer) query.list().get(0);
		return balance;
	}

	public boolean addFeedback(Feedback feedback) {
		Transaction transaction = session.beginTransaction();
		session.save(feedback);
		transaction.commit();
		return true;
	}

	@SuppressWarnings("unchecked")
	public List<Customer> getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		List<Customer> customer = (List<Customer>) session.get(Customer.class, customerId);
		return customer;
	}

	public boolean isCustomerExist(int customerId) {
		// TODO Auto-generated method stub
		Query query = session
				.createQuery("from com.revature.project.banking.Model.Customer where customerid = " + customerId);

		if (query.list().size() != 0) {
			return true;
		} else {
			return false;
		}
	}

	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		Query query = session.createQuery("from com.revature.project.banking.Model.Customer");
		return query.list();
	}

	// Other Function for the website

	@SuppressWarnings("unchecked")
	public boolean loginCustomer(Customer customer) {
		// TODO Auto-generated method stub
		Query query = session.createQuery("from com.revature.project.banking.Model.Customer where customerId = "
				+ customer.getCustomerId() + "and password = '" + customer.getPassword() + "'");
		List<Customer> customerList = query.list();
		if (customerList.size() != 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean depositAmount(CustomerDeposit customerDeposit) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();

		session.save(customerDeposit);
		Query query = session.createQuery("update com.revature.project.banking.Model.Customer set balance = balance + "
				+ customerDeposit.getAmount() + " where customerid = " + customerDeposit.getDepositCustomerId());
		query.executeUpdate();
		transaction.commit();
		return true;
	}

	public boolean transferAmount(TransferAmount transferAmount) {
		Transaction transaction = session.beginTransaction();
		session.save(transferAmount);
		Query updateSenderId = session
				.createQuery("update com.revature.project.banking.Model.Customer set balance = balance - "
						+ transferAmount.getAmount() + " where customerid = " + transferAmount.getSenderCustomerId());
		Query updateReceiverId = session
				.createQuery("update com.revature.project.banking.Model.Customer set balance = balance + "
						+ transferAmount.getAmount() + " where customerid = " + transferAmount.getReceiverCustomerId());
		updateSenderId.executeUpdate();
		updateReceiverId.executeUpdate();
		transaction.commit();
		return true;
	}

	public boolean withdrawAmount(CustomerWithdraw customerWithdraw) {
		Transaction transaction = session.beginTransaction();
		session.save(customerWithdraw);
		Query query = session.createQuery("update com.revature.project.banking.Model.Customer set balance = balance - "
				+ customerWithdraw.getAmount() + " where customerid = " + customerWithdraw.getWithdrawCustomerId());
		query.executeUpdate();
		transaction.commit();
		return true;
	}

}
