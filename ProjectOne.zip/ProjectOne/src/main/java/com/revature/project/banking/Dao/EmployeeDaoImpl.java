package com.revature.project.banking.Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.revature.project.banking.Model.Customer;
import com.revature.project.banking.Model.CustomerDeposit;
import com.revature.project.banking.Model.CustomerWithdraw;
import com.revature.project.banking.Model.Employee;
import com.revature.project.banking.Model.Feedback;
import com.revature.project.banking.Model.RequestTable;
import com.revature.project.banking.Model.TransferAmount;
import com.revature.project.banking.util.HibernateUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
	Session session = sessionFactory.openSession();

	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		Query query = session.createQuery("from com.revature.project.banking.Model.Customer");
		@SuppressWarnings("unchecked")
		List<Customer> customerList = query.list();
		return customerList;
	}

	public Customer getCustomerById(int customerId) {
		// TODO Auto-generated method stub
		Customer customer = (Customer) session.get(Customer.class, customerId);
		return customer;
	}

	public boolean deleteAnCustomerById(int customerId) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		session.delete(customer);
		transaction.commit();
		return true;
	}

	public List<CustomerWithdraw> getAllWithdraws() {
		// TODO Auto-generated method stub
		Query query = session.createQuery("from com.revature.project.banking.Model.CustomerWithdraw");
		@SuppressWarnings("unchecked")
		List<CustomerWithdraw> customerList = query.list();
		return customerList;

	}

	public List<CustomerWithdraw> getWithdrawOfCustomerById(int customerId) {
		// TODO Auto-generated method stub
		Query query = session.createQuery(
				"from com.revature.project.banking.Model.CustomerWithdraw where WithdrawCustomerId = " + customerId);
		@SuppressWarnings("unchecked")
		List<CustomerWithdraw> customerList = query.list();
		return customerList;
	}

	public List<CustomerDeposit> getAllDeposits() {
		Query query = session.createQuery("from com.revature.project.banking.Model.CustomerDeposit");
		@SuppressWarnings("unchecked")
		List<CustomerDeposit> customerList = query.list();
		return customerList;
	}

	public List<CustomerDeposit> getDepositOfCustomerById(int customerId) {
		Query query = session.createQuery(
				"from com.revature.project.banking.Model.CustomerDeposit where DepositCustomerId = " + customerId);
		@SuppressWarnings("unchecked")
		List<CustomerDeposit> customerList = query.list();
		return customerList;
	}

	public List<TransferAmount> getCustomerTransferHistory() {
		Query query = session.createQuery("from com.revature.project.banking.Model.TransferAmount");
		@SuppressWarnings("unchecked")
		List<TransferAmount> transferList = query.list();
		return transferList;
	}

	public List<Feedback> getCustomerFeedBack() {
		Query query = session.createQuery("from com.revature.project.banking.Model.Feedback");
		@SuppressWarnings("unchecked")
		List<Feedback> feedbackList = query.list();
		return feedbackList;
	}

	public List<RequestTable> getAllRequests() {
		Query query = session.createQuery("from com.revature.project.banking.Model.RequestTable");
		@SuppressWarnings("unchecked")
		List<RequestTable> requestList = query.list();
		return requestList;
	}

	public boolean rejectCustomerRequest(int customerId) {
		Transaction transaction = session.beginTransaction();
		RequestTable requestTable = new RequestTable();
		requestTable.setRequestId(customerId);
		session.delete(requestTable);
		transaction.commit();
		return true;

	}

	public boolean approveCustomerRequest(int requestId) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		Query query = session.createSQLQuery("CALL requestApproval(:requestId)").addEntity(RequestTable.class)
				.addEntity(Customer.class).setParameter("requestId", requestId);
		query.executeUpdate();
		transaction.commit();

		return true;
	}

	
	public boolean employeeLogin(Employee employee) {
		Query query = session.createQuery("from com.revature.project.banking.Model.Employee where employeeId= "
				+ employee.getEmployeeId() + "and password = " + employee.getPassword());
		@SuppressWarnings("unchecked")
		List<Employee> employeeList = query.list();
		if (employeeList.size() != 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		session.save(employee);
		transaction.commit();
		return true;
	}



}
